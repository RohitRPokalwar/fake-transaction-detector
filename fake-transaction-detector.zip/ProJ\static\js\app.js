// Fake Transaction Detector Frontend Logic

document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const loader = document.getElementById('loader');
    const errorDiv = document.getElementById('error');
    const resultsDiv = document.getElementById('results');
    const downloadBtn = document.getElementById('downloadBtn');

    let selectedFile = null;

    // File upload handling
    uploadArea.addEventListener('click', () => fileInput.click());

    uploadArea.querySelector('.upload-link').addEventListener('click', (e) => {
        e.stopPropagation();
        fileInput.click();
    });

    fileInput.addEventListener('change', handleFileSelect);
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);

    function handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            validateAndSetFile(file);
        }
    }

    function handleDragOver(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    }

    function handleDragLeave(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
    }

    function handleDrop(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file) {
            validateAndSetFile(file);
        }
    }

    function validateAndSetFile(file) {
        if (!file.name.endsWith('.csv')) {
            showError('Please select a CSV file');
            return;
        }

        selectedFile = file;
        uploadArea.querySelector('p').innerHTML = `File selected: <strong>${file.name}</strong>`;
        analyzeBtn.disabled = false;
        hideError();
    }

    // Analysis
    analyzeBtn.addEventListener('click', analyzeFile);

    async function analyzeFile() {
        if (!selectedFile) return;

        showLoader();
        hideError();
        resultsDiv.style.display = 'none';

        const formData = new FormData();
        formData.append('file', selectedFile);

        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Analysis failed');
            }

            displayResults(data);
        } catch (error) {
            showError(error.message);
        } finally {
            hideLoader();
        }
    }

    function displayResults(data) {
        // Update summary
        document.getElementById('totalTxns').textContent = data.total_transactions;
        document.getElementById('anomalousTxns').textContent = data.anomalous_count;
        const rate = data.total_transactions > 0 ?
            ((data.anomalous_count / data.total_transactions) * 100).toFixed(1) : 0;
        document.getElementById('anomalyRate').textContent = `${rate}%`;

        // Create charts
        createScoreChart(data.results);
        createAnomalyChart(data.results);

        // Populate table
        const tbody = document.querySelector('#resultsTable tbody');
        tbody.innerHTML = '';

        data.results.forEach(row => {
            const tr = document.createElement('tr');
            if (row.is_anomalous) {
                tr.classList.add('anomalous');
            }

            tr.innerHTML = `
                <td>${row.transaction_id || 'N/A'}</td>
                <td>${row.user_id || 'N/A'}</td>
                <td>${row.amount || 'N/A'}</td>
                <td>${row.timestamp || 'N/A'}</td>
                <td>${row.final_score.toFixed(3)}</td>
                <td>${row.is_anomalous ? 'Anomalous' : 'Normal'}</td>
                <td>${row.explanation}</td>
            `;

            tbody.appendChild(tr);
        });

        resultsDiv.style.display = 'block';

        // Setup download
        downloadBtn.onclick = () => downloadAnomalies(data.results);
    }

    function createScoreChart(results) {
        const ctx = document.getElementById('scoreChart').getContext('2d');
        const scores = results.map(r => r.final_score);

        new Chart(ctx, {
            type: 'histogram',
            data: {
                labels: scores.map((_, i) => i + 1),
                datasets: [{
                    label: 'Final Scores',
                    data: scores,
                    backgroundColor: 'rgba(0, 212, 255, 0.6)',
                    borderColor: '#00d4ff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Distribution of Anomaly Scores'
                    }
                },
                scales: {
                    x: {
                        display: false
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function createAnomalyChart(results) {
        const ctx = document.getElementById('anomalyChart').getContext('2d');
        const anomalous = results.filter(r => r.is_anomalous).length;
        const normal = results.length - anomalous;

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Normal', 'Anomalous'],
                datasets: [{
                    data: [normal, anomalous],
                    backgroundColor: ['#28a745', '#dc3545'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Transaction Classification'
                    }
                }
            }
        });
    }

    function downloadAnomalies(results) {
        const anomalies = results.filter(r => r.is_anomalous);
        if (anomalies.length === 0) {
            showError('No anomalies to download');
            return;
        }

        const csvContent = [
            ['Transaction ID', 'User ID', 'Amount', 'Timestamp', 'Final Score', 'Explanation'],
            ...anomalies.map(row => [
                row.transaction_id || '',
                row.user_id || '',
                row.amount || '',
                row.timestamp || '',
                row.final_score,
                row.explanation
            ])
        ].map(row => row.join(',')).join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'anomalous_transactions.csv';
        a.click();
        URL.revokeObjectURL(url);
    }

    // Utility functions
    function showLoader() {
        loader.style.display = 'block';
        analyzeBtn.disabled = true;
    }

    function hideLoader() {
        loader.style.display = 'none';
        analyzeBtn.disabled = false;
    }

    function showError(message) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
    }

    function hideError() {
        errorDiv.style.display = 'none';
    }
});
