class Explain:
    """
    Generate natural language explanations for anomalies.
    """

    def __init__(self):
        pass

    def generate_explanation(self, reasons, ml_score):
        """
        Generate explanation based on rules and ML score.
        """
        explanation = ""

        if reasons:
            explanation += "; ".join(reasons)

        if ml_score > 0.5:
            if explanation:
                explanation += "; "
            explanation += "Machine learning model detected statistical anomaly"

        if not explanation:
            explanation = "No anomalies detected"

        return explanation
