from flask import Flask, request, jsonify, render_template
import pandas as pd
import logging
import traceback
from utils.preprocess import Preprocessor
from utils.ddie import DDIE
from utils.ssg import SSG
from utils.uaic import UAIC
from utils.scoring import HybridScorer
from utils.explain import Explain

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.route('/')
def index():
    """Serve the main dashboard page."""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Analyze uploaded CSV for fake transactions."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'File must be CSV'}), 400

        # Read CSV
        df = pd.read_csv(file)
        logger.info(f"Loaded CSV with {len(df)} rows")

        # Preprocess
        preprocessor = Preprocessor()
        df = preprocessor.clean_data(df)
        logger.info("Preprocessing completed")

        # Apply DDIE rules
        ddie = DDIE()
        rule_results = ddie.apply_rules(df)
        logger.info("DDIE rules applied")

        # Compute stats
        ssg = SSG()
        stats = ssg.compute_global_stats(df)
        logger.info("Statistical signatures computed")

        # ML anomaly detection
        uaic = UAIC()
        if len(df) >= 20:  # Minimum for ML
            ml_scores = uaic.fit_predict(df)
            logger.info("ML model applied")
        else:
            ml_scores = [0.0] * len(df)
            logger.warning("Dataset too small for ML, using rule-only scoring")

        # Hybrid scoring
        scorer = HybridScorer()
        final_scores = []
        for i in range(len(df)):
            rule_score = rule_results.iloc[i]['rule_score']
            ml_score = ml_scores[i]
            final_score = scorer.compute_final_score(rule_score, ml_score)
            final_scores.append(final_score)

        # Generate explanations
        explainer = Explain()
        explanations = []
        for i in range(len(df)):
            reasons = rule_results.iloc[i]['reasons']
            ml_score = ml_scores[i]
            explanation = explainer.generate_explanation(reasons, ml_score)
            explanations.append(explanation)

        # Prepare results
        results = []
        for i in range(len(df)):
            row = df.iloc[i].to_dict()
            row['final_score'] = final_scores[i]
            row['is_anomalous'] = final_scores[i] > 0.6
            row['explanation'] = explanations[i]
            results.append(row)

        # Limit results for response size
        results = results[:5000]

        response = {
            'total_transactions': len(df),
            'anomalous_count': sum(1 for r in results if r['is_anomalous']),
            'results': results,
            'stats': stats
        }

        logger.info(f"Analysis completed: {response['anomalous_count']} anomalies detected")
        return jsonify(response)

    except Exception as e:
        logger.error(f"Error during analysis: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'error': 'Internal server error', 'details': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
