# TODO: Fake Transaction Detector Project

## 1. Create folder structure
- [x] Create directories: utils/, templates/, static/css/, static/js/, sample_data/, tests/
- [ ] Create empty files: app.py, requirements.txt, README.md, utils/__init__.py, etc.

## 2. Install dependencies
- [ ] Create requirements.txt with flask, pandas, numpy, scikit-learn, python-dateutil
- [ ] Run pip install -r requirements.txt

## 3. Build preprocessing module
- [x] Implement utils/preprocess.py for column cleaning and timestamp parsing

## 4. Build DDIE rule engine
- [ ] Implement utils/ddie.py with rules: duplicates, timestamps, amounts, missing fields, time-gap, location conflicts

## 5. Build SSG (stats)
- [x] Implement utils/ssg.py for statistical computations: mean, std, MAD, IQR, seasonality, velocity

## 6. Build UAIC ML model
- [x] Implement utils/uaic.py with Isolation Forest, feature engineering, normalization

## 7. Build scoring system
- [ ] Implement utils/scoring.py with hybrid scoring: 0.4 * rule_score + 0.6 * ml_score

## 8. Build explainability module
- [x] Implement utils/explain.py for natural language explanations

## 9. Build Flask backend
- [ ] Implement app.py with routes: GET /, POST /api/analyze, logging, error handling

## 10. Build frontend UI
- [ ] Implement templates/index.html, static/css/style.css, static/js/app.js with Chart.js, loader, errors, download

## 11. Add sample CSV
- [x] Create sample_data/sample.csv with realistic fake transactions

## 12. Test end-to-end
- [ ] Run Flask app, upload sample CSV, verify results

## 13. Finalize and deploy
- [ ] Add README.md, test with tests/test_rules.py, zip project
